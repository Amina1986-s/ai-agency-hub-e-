---
name: Neo-Enterprise AI
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#3a3939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#becab9'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#889484'
  outline-variant: '#3f4a3d'
  surface-tint: '#77dc7a'
  primary: '#ffffff'
  on-primary: '#00390c'
  primary-container: '#93f993'
  on-primary-container: '#007523'
  inverse-primary: '#006e20'
  secondary: '#ffb3b1'
  on-secondary: '#680011'
  secondary-container: '#d1032d'
  on-secondary-container: '#ffe1e0'
  tertiary: '#ffffff'
  on-tertiary: '#00391e'
  tertiary-container: '#78fbaf'
  on-tertiary-container: '#007443'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#93f993'
  primary-fixed-dim: '#77dc7a'
  on-primary-fixed: '#002105'
  on-primary-fixed-variant: '#005316'
  secondary-fixed: '#ffdad8'
  secondary-fixed-dim: '#ffb3b1'
  on-secondary-fixed: '#410007'
  on-secondary-fixed-variant: '#92001c'
  tertiary-fixed: '#78fbaf'
  tertiary-fixed-dim: '#5ade95'
  on-tertiary-fixed: '#002110'
  on-tertiary-fixed-variant: '#00522e'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  display-lg:
    fontFamily: Sora
    fontSize: 72px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: Sora
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Sora
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Sora
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  accent-label:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.1em
  mono-technical:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '400'
    lineHeight: '1.4'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  unit-1: 4px
  unit-2: 8px
  unit-4: 16px
  unit-6: 24px
  unit-8: 32px
  unit-12: 48px
  unit-16: 64px
  container-max: 1440px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 64px
---

## Brand & Style
This design system establishes a high-stakes, futuristic corporate aesthetic tailored for the next generation of artificial intelligence. It blends the clinical precision of enterprise software with the vibrant, high-energy signals of cutting-edge technology. 

The visual language is rooted in **Glassmorphism** and **Futuristic Minimalism**. It utilizes deep, "infinite" backgrounds contrasted against sharp, technical accents. The emotional goal is to evoke a sense of absolute power, sophisticated intelligence, and premium reliability. Heavy use of backdrop blurs, metallic sheen, and neon light-trails creates a UI that feels like a high-end command center.

## Colors
The palette is dominated by **Midnight Black (#050505)** to provide an infinite canvas for light-based components. **Matcha Green** serves as the primary action color, symbolizing growth and digital vitality, while **Neon Mint** is used for high-visibility data points and success states. **Cherry Red** is reserved for high-contrast disruptions, critical alerts, and premium "power" features.

**Metallic Silver** is used for subtle borders and iconography to introduce a physical, high-end hardware feel. In Light Mode, the system pivots to **Soft Cream (#F8F6F0)**, maintaining a luxury "executive paper" feel while keeping the Matcha and Cherry accents for brand continuity.

## Typography
The typography strategy prioritizes authority and technical precision. 
- **Sora** is the primary display face, providing a geometric, wide-stanced silhouette that feels engineered and premium. 
- **Inter** handles all long-form reading and interface labels, ensuring maximum legibility across dense data sets.
- **Space Grotesk** is utilized for specialized accents, "overlines," and technical metadata, lending an experimental, futuristic edge to the corporate structure.

For mobile, large display sizes scale aggressively to maintain a single-column impact without breaking word-wraps.

## Layout & Spacing
This design system utilizes a **12-column fluid grid** for desktop, optimized for the `container-max` of 1440px. The spacing rhythm is strictly based on a **4px baseline**, creating a tight, mathematical feel essential for an AI-focused product.

Large "Macro-spacing" (64px+) is encouraged between major sections to emphasize the "Luxury" aspect of the brand through intentional whitespace (or "blackspace"). For data-heavy views, the system shifts to a "Technical Density" where margins collapse to 16px to maximize information throughput.

## Elevation & Depth
Depth is achieved through **Glassmorphism** and **Tonal Layering** rather than traditional drop shadows.
- **Surface Level 0:** Midnight Black background.
- **Surface Level 1 (Containers):** Deep Charcoal with a 1px Metallic Silver outline at 10% opacity.
- **Surface Level 2 (Floating Modals):** Semi-transparent Charcoal with a `backdrop-filter: blur(20px)` and a subtle Matcha Green inner glow (1px, 20% opacity).

Instead of shadows, use "Glows" for interactive elements. A hovered button should emit a soft Matcha Green or Cherry Red outer aura to simulate light radiation on a dark dashboard.

## Shapes
The shape language is **Soft (0.25rem)**, leaning toward a more architectural and "serious" feel. While many modern apps use large rounds, this design system uses tighter corners to maintain its corporate and technical identity. 

Interactive components like buttons and inputs use the standard `rounded` (4px), while large containers use `rounded-lg` (8px). Pills and circles are reserved exclusively for status indicators and user avatars to create visual distinction from functional UI.

## Components
- **Buttons:** Primary buttons use a solid Matcha Green background with black text. Secondary buttons use a "Ghost" style with a Metallic Silver 1px border and a subtle glass blur.
- **Chips/Badges:** Small, uppercase labels using **Space Grotesk**. High-priority badges use the Cherry Red background with white text.
- **Inputs:** Dark backgrounds with a 1px Metallic Silver bottom-border only, becoming Matcha Green upon focus with a slight neon "line-glow" effect.
- **Cards:** Utilize the Level 1 Surface styling. Titles should be in **Sora**, while the content remains in **Inter**.
- **The "Pulse" Indicator:** A signature component for this design system—a small, animated Matcha Green dot that signifies "AI Active" or "System Live," placed in the top-right of primary containers.
- **Glass Headers:** Sticky navigation bars must use a heavy backdrop blur (30px) with a 20% transparent Midnight Black tint.